import { APIGatewayProxyEvent, APIGatewayProxyResult } from "aws-lambda";
export declare const createUser: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
export declare const getUser: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
//# sourceMappingURL=userHandlers.d.ts.map