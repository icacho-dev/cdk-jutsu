"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const userHandlers_1 = require("./handlers/userHandlers");
const handler = async (event) => {
    console.log("Event:", JSON.stringify(event, null, 2));
    try {
        const { httpMethod, pathParameters } = event;
        switch (httpMethod) {
            case "POST":
                return await (0, userHandlers_1.createUser)(event);
            case "GET":
                if (pathParameters?.userId) {
                    return await (0, userHandlers_1.getUser)(event);
                }
                break;
            default:
                return {
                    statusCode: 405,
                    body: JSON.stringify({ message: "Method not allowed" }),
                };
        }
        return {
            statusCode: 404,
            body: JSON.stringify({ message: "Not found" }),
        };
    }
    catch (error) {
        console.error("Error:", error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: "Internal server error" }),
        };
    }
};
exports.handler = handler;
//# sourceMappingURL=index.js.map